<?php
	header( "Content-Type: text/plain" );
	echo( file_get_contents( "redirect.php" ) );
?>
